﻿// define application
var app = angular.module('app', ['wj']);
