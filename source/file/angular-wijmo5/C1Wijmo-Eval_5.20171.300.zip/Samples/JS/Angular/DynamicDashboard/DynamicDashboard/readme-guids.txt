﻿9d95d9aa-0374-42bc-b82f-a38e35d1fe34		Common Guid shared by sample with multiple languages.
d6f73aa6-042c-474f-ba81-b89c732752d6		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
