namespace Models.NorthwindIB.NH
{
    using System;
    using System.Collections.Generic;

    public partial class NextId
    {
        public virtual string Name { get; set; }
        public virtual long NextId1 { get; set; }
    }
}
