
namespace Models.NorthwindIB.NH {
  public enum RoleType {
    Guest = 0,
    Restricted = 1,
    Standard = 2,
    Admin = 3
  }
}
