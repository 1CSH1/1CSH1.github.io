﻿1775AC2E-233B-4939-979C-FCAA266E5444		Common Guid shared by sample with multiple languages.
E461099D-C7ED-4D06-9023-B08019D4E8C8		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
