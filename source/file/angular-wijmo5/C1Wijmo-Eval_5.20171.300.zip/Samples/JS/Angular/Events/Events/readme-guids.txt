5496193D-6FE1-4144-8F76-242C0E6F28A4		Common Guid shared by sample with multiple languages.
8D78AD56-EDCA-4E87-9894-1AC16BCE8AC8		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>