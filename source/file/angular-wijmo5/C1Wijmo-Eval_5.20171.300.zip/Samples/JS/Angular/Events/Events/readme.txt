﻿Events
------------------------------------------------------------------------------
Shows how to handle Wijmo control events.

The sample shows how to attach handlers to Wijmo events, and also how to 
integrate them with the AngularJS event broadcasting infrastructure.
