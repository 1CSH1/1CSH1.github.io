﻿01056020-2563-4104-B55A-8D0AAA570634		Common Guid shared by sample with multiple languages.
AD7A58DF-DC2F-4CD6-9E29-26FC396F80D2		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
