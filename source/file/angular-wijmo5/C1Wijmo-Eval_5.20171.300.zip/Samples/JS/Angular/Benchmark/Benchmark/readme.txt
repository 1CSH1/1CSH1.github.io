﻿Benchmark
------------------------------------------------------------------------------
Compares the performance of several grid and chart controls.

Keep in mind that binding performance is only one of the criteria to use when 
choosing a control.

Performance after the initial binding is also important, as well as features,
ease-of-use, appearance, size/footprint, support, etc.
