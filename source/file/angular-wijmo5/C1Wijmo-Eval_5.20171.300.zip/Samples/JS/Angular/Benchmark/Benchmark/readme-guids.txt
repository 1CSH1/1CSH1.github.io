B73E4B26-64E0-4043-A7FE-5A4725679951		Common Guid shared by sample with multiple languages.
A774BD7A-5891-4014-B649-8D66CEDDFB11		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>