﻿839397C6-3EB0-495F-B9DB-DC7E4681534C		Common Guid shared by sample with multiple languages.
A7656BD4-1EC6-4A3F-8FF2-316D155CA7CB		Unique Guid for each sample regardless of language.

