﻿47331CBD-F348-459E-829D-67521C27E231		Common Guid shared by sample with multiple languages.
732D7083-AC17-4AA4-93A1-EF4E48EF8BF3		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
