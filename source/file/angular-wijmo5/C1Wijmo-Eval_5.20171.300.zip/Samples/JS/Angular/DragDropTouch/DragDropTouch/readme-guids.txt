﻿148dee25-5436-4619-ac68-a3bee20b7df7		Common Guid shared by sample with multiple languages.
ee656db3-b496-4803-a7f8-6057f7f70c24		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
