﻿// define angular app (with dependency on Wijmo)
angular.module('app', ['wj']);