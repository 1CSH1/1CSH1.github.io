﻿889AFF98-D19E-4D99-9ABF-19DF05E30B81		Common Guid shared by sample with multiple languages.
6215D1D0-8687-4F2D-8836-34B664404F97		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
