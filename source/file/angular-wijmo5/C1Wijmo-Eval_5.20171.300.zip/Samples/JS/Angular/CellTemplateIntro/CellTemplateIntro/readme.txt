﻿CellTemplateIntro (Angular)
------------------------------------------------------------------------------
Shows how to apply templates to different types of cells declaratively in markup.

Shows how to apply templates to different types of cells declaratively in markup.
