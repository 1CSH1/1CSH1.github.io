81EE85CE-7D16-48ED-B4AB-27DDA5FF69FA		Common Guid shared by sample with multiple languages.
D4FCBF0C-76B0-427A-B883-433FCD5E9564		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>