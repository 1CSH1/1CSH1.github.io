﻿82937ded-295b-42bf-95ee-02af514bfe9e		Common Guid shared by sample with multiple languages.
8c16b2df-b423-4858-855c-cda396d17cf9		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
