﻿FlexChartAnalytics (Angular)
------------------------------------------------------------------------------
Demonstrates features included into the wijmo.chart.analytics module.

The sample shows how to display various trendlines and functions using FlexChart.
