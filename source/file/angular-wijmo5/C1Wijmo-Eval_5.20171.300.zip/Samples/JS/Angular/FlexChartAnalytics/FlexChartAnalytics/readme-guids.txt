9A6E67D3-A776-4CD9-86EC-0F9E2FE0D5AE		Common Guid shared by sample with multiple languages.
613F5700-2C1D-4C68-A413-EA1D53E5A3AC		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>