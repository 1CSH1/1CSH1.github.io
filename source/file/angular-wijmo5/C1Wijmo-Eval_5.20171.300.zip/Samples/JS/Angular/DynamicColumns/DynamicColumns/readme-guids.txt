﻿87893D7F-D448-48A8-BC3A-1AA020DA356B		Common Guid shared by sample with multiple languages.
89A72493-CF98-4F7A-8F4B-F1453BDAE7AD		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
