﻿522b9bb2-b8f5-45d5-ad15-4354047edca8		Common Guid shared by sample with multiple languages.
76085937-4e67-40e3-aa7f-5a26e97dbb10		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
