BC9C3B9D-5AD7-4042-A1A2-6B2C6C0D3FA0		Common Guid shared by sample with multiple languages.
9280B2D4-C2EE-4A12-B8F2-3759AE188AFF		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>