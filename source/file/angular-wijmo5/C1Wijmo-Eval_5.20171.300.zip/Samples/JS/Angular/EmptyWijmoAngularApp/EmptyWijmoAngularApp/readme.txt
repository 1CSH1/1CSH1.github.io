﻿EmptyWijmoAngularApp
-------------------------------------------------------------
A minimal Wijmo 5 AngularJS application.

This application consists of a single view with a FlexGrid and 
a FlexChart showing the same data.

The view is bound to a simple controller that generates some
data and exposes it as an ICollectionView.
