﻿//
// Define app module including any dependencies.
//
// Our app depends on module 'wj', which contains AngularJS directives for the Wijmo 5 controls.
//
var app = angular.module('app', ['wj']);

