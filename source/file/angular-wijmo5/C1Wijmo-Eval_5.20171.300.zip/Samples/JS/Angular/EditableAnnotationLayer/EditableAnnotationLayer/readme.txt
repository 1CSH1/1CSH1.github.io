﻿EditableAnnotationLayer (Angular)
------------------------------------------------------------------------------
Shows how to edit annotations on FlexChart.

The sample shows how to add, delete and drag annotations with several shapes on FlexChart.
The annotation functionality is included into wijmo.chart.annotation module.
