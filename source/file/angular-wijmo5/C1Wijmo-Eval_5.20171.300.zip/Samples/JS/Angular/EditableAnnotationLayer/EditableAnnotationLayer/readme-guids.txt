﻿25BFF938-9BE3-4030-92AC-D52A1C4CB838		Common Guid shared by sample with multiple languages.
A58A364E-A280-4FF2-B48B-6104ACA4A8EA		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
