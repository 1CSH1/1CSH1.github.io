﻿994A7419-E391-4000-B86E-C206B92B0394		Common Guid shared by sample with multiple languages.
2FD0004A-67AF-40C2-B2B0-1FF3F6B818E5		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
