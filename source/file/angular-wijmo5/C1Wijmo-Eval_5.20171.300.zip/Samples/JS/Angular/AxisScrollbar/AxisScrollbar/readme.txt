﻿Wijmo FlexChart Axis Scrollbar
---------------------------
Shows how to add scrollbar to axis of FlexChart.

The sample displays Axis Scrollbar in FlexChart, user can change the data range displayed on the chart.
