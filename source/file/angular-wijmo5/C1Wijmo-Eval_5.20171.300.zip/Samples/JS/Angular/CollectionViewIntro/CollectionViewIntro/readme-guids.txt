51938438-7D5C-4C32-8841-33F647F085D5		Common Guid shared by sample with multiple languages.
0592F010-E07B-4613-ABC5-2B1AECDD1484		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>