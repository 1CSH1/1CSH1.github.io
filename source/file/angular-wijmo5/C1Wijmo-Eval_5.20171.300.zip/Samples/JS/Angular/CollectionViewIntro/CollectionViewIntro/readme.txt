﻿CollectionViewIntro (Angular)
------------------------------------------------------------------------------
Shows how to get started with CollectionView, our .NET-like class that uses regular JavaScript arrays as data sources.

The sample shows one page with how-to's for the most important functionality of the CollectionView class.
