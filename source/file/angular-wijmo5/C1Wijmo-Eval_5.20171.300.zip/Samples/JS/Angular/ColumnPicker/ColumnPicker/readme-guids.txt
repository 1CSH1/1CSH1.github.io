﻿6C8329A0-85A4-4202-8C3B-8E11B7522D8D		Common Guid shared by sample with multiple languages.
7D2EA278-0D77-493A-BEEB-1DCCC05DC2B2		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
