DD7694BB-02F0-4073-9C84-45D3B286C4E4		Common Guid shared by sample with multiple languages.
73E25B48-5561-48AE-A8C2-10052E5D889D		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>