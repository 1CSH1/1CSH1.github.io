﻿10A7AA89-ABDE-4925-8E77-154AA36F8543		Common Guid shared by sample with multiple languages.
2619D67B-B24B-4381-89E9-ED2760454C88		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
