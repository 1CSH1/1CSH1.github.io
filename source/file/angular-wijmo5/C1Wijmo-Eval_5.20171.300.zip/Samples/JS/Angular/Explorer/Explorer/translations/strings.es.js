﻿{
	"greetings": {
		"cheers": "Salud",
        "hello": "Hola",
        "bye": "Adiós"
	},
    "menu": {
        "file": {
            "_root": "Archivo",
		    "new": "Nuevo",
		    "open": "Abrir",
		    "save": "Guardar",
            "exit": "Salir"
        },
	    "edit": {
	        "_root": "Editar",
		    "cut": "Cortar",
		    "copy": "Copiar",
		    "paste": "Pegar",
		    "find": "Encontrar",
		    "replace": "Reemplazar"
        }, 
	    "format": {
	        "_root": "Formato",
		    "bold": "Negrita",
		    "italic": "Itálico",
		    "underline": "Subrayar"
		}
    }
}