﻿{
	"greetings": {
	    "cheers": "干杯",
		"hello": "您好",
        "bye": "再见"
	},
    "menu": {
        "file": {
            "_root": "文件",
		    "new": "新建",
		    "open": "打开",
		    "save": "保存",
            "exit": "退出"
		},
	    "edit": {
	        "_root": "编辑",
		    "cut": "剪切",
		    "copy": "复制",
		    "paste": "粘贴",
		    "find": "查找",
		    "replace": "替换"
		}, 
	    "format": {
	        "_root": "格式",
		    "bold": "粗体",
		    "italic": "斜体",
		    "underline": "下划线"
		}
    }
}