﻿{
	"greetings": {
		"cheers": "Santé",
		"hello": "Bonjour",
        "bye": "Au Revoir"
	},
	"menu": {
	    "file": {
	        "_root": "Dossier",
		    "new": "Nouveau",
		    "open": "Ouvrir",
		    "save": "Sauver",
            "exit": "Quitter"
	    },
	    "edit": {
	        "_root": "Modifier",
		    "cut": "Cut",
		    "copy": "Copie",
		    "paste": "Coller",
		    "find": "Trouver",
		    "replace": "Remplacer"
	    }, 
	    "format": {
	        "_root": "Format",
		    "bold": "Audacieux",
		    "italic": "Italique",
		    "underline": "Souligner"
	    }
	}
}