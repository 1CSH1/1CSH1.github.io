﻿{
	"greetings": {
	    "cheers": "건배",
		"hello": "안녕하세요.",
        "bye": "안녕"
	},
    "menu": {
        "file": {
            "_root": "파일",
		    "new": "새로운",
		    "open": "열린",
		    "save": "저장",
            "exit": "출구"
		},
	    "edit": {
	        "_root": "편집",
		    "cut": "절단",
		    "copy": "부",
		    "paste": "풀",
		    "find": "발견",
		    "replace": "교체"
		}, 
	    "format": {
	        "_root": "체재",
		    "bold": "대담한",
		    "italic": "이탤릭체",
		    "underline": "밑줄"
		}
    }
}