﻿{
	"greetings": {
		"cheers": "Saúde",
        "hello": "Olá",
        "bye": "Tchau"
	},
    "menu": {
        "file": {
            "_root": "Arquivo",
		    "new": "Novo",
		    "open": "Abrir",
		    "save": "Salvar",
            "exit": "Sair"
        },
	    "edit": {
	        "_root": "Editar",
		    "cut": "Cortar",
		    "copy": "Copiar",
		    "paste": "Colar",
		    "find": "Encontrar",
		    "replace": "Substituir"
        }, 
	    "format": {
	        "_root": "Formato",
		    "bold": "Negrito",
		    "italic": "Itálico",
		    "underline": "Sublinhado"
		}
    }
}