﻿{
	"greetings": {
		"cheers": "Saluti",
        "hello": "Ciao",
        "bye": "Ciao"
	},
	"menu": {
	    "file": {
	        "_root": "Archivio",
		    "new": "Nuovo",
		    "open": "Aprire",
		    "save": "Salvare",
            "exit": "Uscire"
	    },
	    "edit": {
	        "_root": "Modifica",
		    "cut": "Cut",
		    "copy": "Copia",
		    "paste": "Incolla",
		    "find": "Trovare",
		    "replace": "Sostituire"
	    }, 
	    "format": {
	        "_root": "Formato",
		    "bold": "Audace",
		    "italic": "Italico",
		    "underline": "Sottolineare"
	    }
	}
}