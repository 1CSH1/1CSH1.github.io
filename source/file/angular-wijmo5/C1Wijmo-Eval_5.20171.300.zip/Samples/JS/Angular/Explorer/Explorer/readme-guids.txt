24952C4C-9AD8-43B5-BA48-421CFEE61BAA		Common Guid shared by sample with multiple languages.
B809E2C2-C370-4AEC-BDF4-B00BD96B9072		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>