﻿{
	"greetings": {
		"cheers": "喝采",
		"hello": "こんにちは",
        "bye": "さようなら"
	},
	"menu": {
	    "file": {
	        "_root": "ファイル",
		    "new": "新しい",
		    "open": "オープン",
		    "save": "保存",
            "exit": "出口"
	    },
	    "edit": {
	        "_root": "編集",
		    "cut": "カット",
		    "copy": "コピー",
		    "paste": "ペースト",
		    "find": "見つける",
		    "replace": "交換する"
	    }, 
	    "format": {
	        "_root": "フォーマット",
		    "bold": "大胆な",
		    "italic": "イタリック",
		    "underline": "下線"
	    }
	}
}