﻿{
	"greetings": {
		"cheers": "Prost",
		"hello": "Hallo",
        "bye": "Tschüs"
	},
    "menu": {
        "file": {
            "_root": "Datei",
		    "new": "Neo",
		    "open": "Offnen",
		    "save": "Sparen",
            "exit": "Beenden"
        },
	    "edit": {
	        "_root": "Bearbeiten ",
		    "cut": "Cut",
		    "copy": "Kopie",
		    "paste": "Einfügen",
		    "find": "Finden",
		    "replace": "Ersetzen"
		    }, 
	    "format": {
	        "_root": "Format",
		    "bold": "Fett",
		    "italic": "Kursiv",
		    "underline": "Unterstreichen"
        }
    }
}