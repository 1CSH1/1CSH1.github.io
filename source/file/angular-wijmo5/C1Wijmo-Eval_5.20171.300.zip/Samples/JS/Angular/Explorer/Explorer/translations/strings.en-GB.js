﻿{
	"greetings": {
		"cheers": "Cheers",
		"hello": "Hello",
        "bye": "Bye"
	},
    "menu": {
        "file": {
            "_root": "File",
		    "new": "New",
		    "open": "Open",
		    "save": "Save",
            "exit": "Exit"
		},
	    "edit": {
	        "_root": "Edit",
		    "cut": "Cut",
		    "copy": "Copy",
		    "paste": "Paste",
		    "find": "Find",
		    "replace": "Replace"
		}, 
	    "format": {
	        "_root": "Format",
		    "bold": "Bold",
		    "italic": "Italic",
		    "underline": "Underline"
		}
    }
}