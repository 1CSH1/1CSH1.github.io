﻿BC1B037D-1CEA-4759-B062-C3548ED9C3DD		Common Guid shared by sample with multiple languages.
31B16DA7-7423-4C47-96B8-2DB9AE6183B8		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
