﻿BEA99E2E-6CD7-46A2-B6E2-83C06BE3DD89		Common Guid shared by sample with multiple languages.
F1C7480C-6A8B-44B3-B02C-0CC1287ABC44		Unique Guid for each sample regardless of language.

<product>Wijmo 5;HTML5</product>
